import math
import numpy as np
import random
import copy 
import pandas as pd

eps = 1e-9
dT = 0.01
cut = 2
gravity = 9.8
M_INITIAL = [np.array([20000, 0, 2000], dtype=np.float64), np.array([19000, 600, 2100], dtype=np.float64), np.array([18000, -600, 1900], dtype=np.float64)]
FY_INITIAL = [np.array([17800, 0, 1800], dtype=np.float64), np.array([12000, 1400, 1400], dtype=np.float64), np.array([6000, -3000, 700], dtype=np.float64)]
M = None
FY = None
missile_speed = 300
object_axis = np.array([0, 200, 0])
object_radius = 7
object_height = 10
cluster_speed = 3
cluster_radius = 10
effective_shielding = 20

def get_norm(delta): return np.linalg.norm(delta)
def line_point_distance(p1, p2, c):
    v, w = p2 - p1, c - p1
    s = np.dot(w, v) / np.dot(v, v)
    s_clamped = np.clip(s, 0.0, 1.0)
    closest = p1 + s_clamped * v
    return np.linalg.norm(c - closest)
def check_if_cover(missile, cluster):
    candidate_points = []
    for i in range(cut):
        angle = 2 * math.pi / cut * i
        candidate_points.extend([
            (object_axis[0] + object_radius * math.cos(angle), object_axis[1] + object_radius * math.sin(angle), object_axis[2]),
            (object_axis[0] + object_radius * math.cos(angle), object_axis[1] + object_radius * math.sin(angle), object_axis[2] + object_height)
        ])
    for c_point in candidate_points:
        if line_point_distance(missile, c_point, cluster) > cluster_radius:
            return False
    return True

def processing(drone_direction, drone_speed, release_time, detonate_time):
    global M, FY 
    
    if isinstance(drone_direction, list):
        drone_direction = np.array(drone_direction)

    cluster = []
    total_cover_time = 0
    time_table = np.arange(0, 100, dT)
    
    individual_cover_times = [0.0] * 3

    for T in time_table:
        for i in range(3): 
            for j in range(len(release_time[i])): 
                if abs(T - detonate_time[i][j]) < dT:
                    cluster.append((FY[i][0], FY[i][1], 
                                    FY[i][2] - 0.5 * gravity * ((detonate_time[i][j] - release_time[i][j]) ** 2), 
                                    detonate_time[i][j], detonate_time[i][j] + effective_shielding, 
                                    i)) 
        
        is_covered_this_step = False
        contributing_bomb_id = -1
        for c in cluster:
            bomb_index = c[5] 
            if (T <= c[4]) and (check_if_cover(M[0], (c[0], c[1], c[2] - cluster_speed * (T - c[3])))):
                is_covered_this_step = True
                contributing_bomb_id = bomb_index
                break 
        
        if is_covered_this_step:
            total_cover_time += dT
            if contributing_bomb_id != -1:
                individual_cover_times[contributing_bomb_id] += dT
        
        for i in range(len(M)):
            norm = get_norm(M[i])
            if norm > eps:
                unit = M[i] / norm * (missile_speed * dT)
                M[i] -= unit
        for i in range(len(FY)):
            norm = get_norm(drone_direction[i])
            if norm < eps:
                continue
            unit = drone_direction[i] / norm * (drone_speed[i] * dT)
            FY[i] += unit
        
    return total_cover_time, individual_cover_times

POPULATION_SIZE = 100
# 变量: [FY1角度, FY1速度, FY1投放, FY1延迟, FY2角度, ..., FY3延迟]
NUM_VARIABLES = 12 
angle_range = (0, 2 * math.pi)
speed_range = (70, 140)
time_range = (0, 50)
delay_range = (0, 18) 

VARIABLE_RANGES = [
    angle_range, speed_range, time_range, delay_range,
    angle_range, speed_range, time_range, delay_range,
    angle_range, speed_range, time_range, delay_range,
]

MAX_GENERATIONS = 100 
CROSSOVER_RATE = 0.8        
MUTATION_RATE = 0.05        
TOURNAMENT_SIZE = 5         
ELITISM_COUNT = 1          

def initialize_population():
    population = []

    angle1 = math.radians(6.7)
    speed1 = 130.5 
    r_time1 = 0.12
    d_delay1 = 0.685

    angle2 = math.radians(301.8958)
    speed2 = 119.6799
    r_time2 = 9.5237
    d_delay2 = 4.1635

    angle3 = math.radians(81.1268)
    speed3 = 122.5000
    r_time3 = 25.0000
    d_delay3 = 0

    seed_individual = [
        angle1, speed1, r_time1, d_delay1,
        angle2, speed2, r_time2, d_delay2,
        angle3, speed3, r_time3, d_delay3,
    ]
    population.append(seed_individual)
    
    while len(population) < POPULATION_SIZE:
        individual = []
        for i in range(NUM_VARIABLES):
            min_val, max_val = VARIABLE_RANGES[i]
            individual.append(random.uniform(min_val, max_val))
        population.append(individual)
    return population

def calculate_fitness(individual):
    global M, FY
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)
    
    angle1, speed1, r_time1, d_delay1, angle2, speed2, r_time2, d_delay2, angle3, speed3, r_time3, d_delay3 = individual

    dir1 = np.array([math.cos(angle1), math.sin(angle1), 0])
    dir2 = np.array([math.cos(angle2), math.sin(angle2), 0])
    dir3 = np.array([math.cos(angle3), math.sin(angle3), 0])
    drone_dir = [dir1, dir2, dir3]
    drone_spd = [speed1, speed2, speed3]
    release_times = [[r_time1], [r_time2], [r_time3]]
    detonate_times = [[r_time1 + d_delay1], [r_time2 + d_delay2], [r_time3 + d_delay3]]
    
    total_fitness, _ = processing(drone_dir, drone_spd, release_times, detonate_times)
    
    return total_fitness

def selection(population, fitnesses):
    tournament = random.sample(list(enumerate(population)), TOURNAMENT_SIZE)
    best_individual = max(tournament, key=lambda item: fitnesses[item[0]])[1]
    return best_individual
def crossover(parent1, parent2):
    if random.random() > CROSSOVER_RATE: return parent1[:], parent2[:]  
    point = random.randint(1, NUM_VARIABLES - 1)
    child1, child2 = parent1[:point] + parent2[point:], parent2[:point] + parent1[point:]
    return child1, child2
def mutate(individual):
    for i in range(NUM_VARIABLES):
        if random.random() < MUTATION_RATE:
            individual[i] = random.uniform(*VARIABLE_RANGES[i])
    return individual

def printqwq(global_best_individual):
    global M, FY
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)

    angle1, speed1, r_t1, d_d1, angle2, speed2, r_t2, d_d2, angle3, speed3, r_t3, d_d3 = global_best_individual
    
    dir1 = np.array([math.cos(angle1), math.sin(angle1), 0])
    dir2 = np.array([math.cos(angle2), math.sin(angle2), 0])
    dir3 = np.array([math.cos(angle3), math.sin(angle3), 0])
    drone_dir = [dir1, dir2, dir3]
    drone_spd = [speed1, speed2, speed3]
    release_times_list = [[r_t1], [r_t2], [r_t3]]
    detonate_times_list = [[r_t1 + d_d1], [r_t2 + d_d2], [r_t3 + d_d3]]

    final_total_time, final_individual_times = processing(drone_dir, drone_spd, release_times_list, detonate_times_list)
    
    strategies = [
        (angle1, speed1, r_t1, d_d1), (angle2, speed2, r_t2, d_d2), (angle3, speed3, r_t3, d_d3),
    ]
    for i in range(3):
        angle, speed, r_time, d_delay = strategies[i]
        print(f"\FY{i+1} 飞行速度: {speed:.4f} 飞行角度: {math.degrees(angle):.4f} 投放时间: {r_time:.4f} 起爆时间: {r_time + d_delay:.4f} ")

    if final_individual_times:
        for i, t in enumerate(final_individual_times):
            print(f"FY{i+1} 的贡献时长弹: {t:.4f} s")

    print(f"找到的最长有效遮蔽时间: {final_total_time:.4f} s")
    print("="*30)

def genetic_algorithm():
    population = initialize_population()
    global_best_individual = None
    global_best_fitness = -float('inf')
    
    for g in range(MAX_GENERATIONS):
        fitnesses = [calculate_fitness(ind) for ind in population]
        
        current_best_idx = np.argmax(fitnesses)
        if fitnesses[current_best_idx] > global_best_fitness:
            global_best_fitness = fitnesses[current_best_idx]
            global_best_individual = population[current_best_idx]

        print(f"第 {g+1}/{MAX_GENERATIONS} 代: 最长遮蔽时间 = {global_best_fitness:.4f} s")

        printqwq(global_best_individual)
    
        
        next_generation = []
        sorted_population = sorted(zip(population, fitnesses), key=lambda x: x[1], reverse=True)
        for i in range(ELITISM_COUNT):
            next_generation.append(sorted_population[i][0])
            
        while len(next_generation) < POPULATION_SIZE:
            parent1 = selection(population, fitnesses)
            parent2 = selection(population, fitnesses)
            child1, child2 = crossover(parent1, parent2)
            mutate(child1); mutate(child2)
            next_generation.append(child1)
            if len(next_generation) < POPULATION_SIZE:
                next_generation.append(child2)
        population = next_generation

    printqwq(global_best_individual)
    
    return global_best_individual, global_best_fitness


if __name__ == "__main__":
    best_solution, best_value = genetic_algorithm()