import math
import numpy as np
import matplotlib.pyplot as plt

# 数据和常量
solution_q3 = {
    'drone_id': 'FY1', 'missile_id': 'M1', 'total_time': 7.36,
    'speed': 139.0863, 'angle_rad': 3.1351,
    'release_times': [0.0000, 3.6318, 5.1401],
    'detonation_times': [3.6000, 9.0207, 10.9814],
    'contributions': [3.88, 2.58, 0.90]
}
FY_INITIAL = {'FY1': np.array([17800, 0, 1800])}
M_INITIAL = {'M1': np.array([20000, 0, 2000])}
TARGET_POS = np.array([0, 0, 0])
GRAVITY = 9.8

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def get_bomb_locations(solution):
    start_pos = FY_INITIAL[solution['drone_id']]
    speed = solution['speed']
    angle_rad = solution['angle_rad']
    unit_dir = np.array([math.cos(angle_rad), math.sin(angle_rad), 0])
    release_points, detonation_points = [], []
    for r_time, d_time in zip(solution['release_times'], solution['detonation_times']):
        if d_time < r_time: continue
        rp = start_pos + unit_dir * speed * r_time
        release_points.append(rp)
        drone_pos_at_det = start_pos + unit_dir * speed * d_time
        fall_duration = d_time - r_time
        z_fallen = 0.5 * GRAVITY * (fall_duration ** 2)
        dp = np.array([drone_pos_at_det[0], drone_pos_at_det[1], rp[2] - z_fallen])
        detonation_points.append(dp)
    return release_points, detonation_points

def plot_q3(solution):
    # 设置3:2的长宽比
    plt.figure(figsize=(12, 8))
    ax = plt.gca()
    
    # 设定配色方案
    face_colors = [
        (250/255, 170/255, 137/255), 
        (255/255, 220/255, 126/255), 
        (173/255, 206/255, 215/255)
    ]
    darkness_factor = 0.6
    edge_colors = [tuple(c * darkness_factor for c in color) for color in face_colors]
    
    #绘制路径
    drone_start = FY_INITIAL[solution['drone_id']]
    max_time = max(solution['detonation_times']) + 5 
    path = np.array([drone_start + np.array([math.cos(solution['angle_rad']), math.sin(solution['angle_rad']), 0]) * solution['speed'] * t for t in np.linspace(0, max_time, 200)])
    
    ax.plot([M_INITIAL['M1'][0], TARGET_POS[0]], [M_INITIAL['M1'][1], TARGET_POS[1]], 'k--', linewidth=2, label='导弹 M1 路径')
    
    # 设定无人机路径颜色
    drone_path_color = (203/255, 185/255, 183/255)
    ax.plot(path[:, 0], path[:, 1], '-', linewidth=2.5, color=drone_path_color, label=f'无人机 {solution["drone_id"]} 路径')
    
    # 绘制烟幕弹相关点
    release_points, detonation_points = get_bomb_locations(solution)
    for i, (rp, dp) in enumerate(zip(release_points, detonation_points)):
        # 绘制烟幕范围
        ax.scatter(dp[0], dp[1], s=5000, c=[face_colors[i]], alpha=0.4, edgecolors='none')
        # 绘制投放点
        ax.scatter(rp[0], rp[1], marker='x', s=150, c=[edge_colors[i]], linewidth=2.5, label=f'烟幕弹 {i+1} 投放点')
        # 绘制起爆点
        ax.scatter(dp[0], dp[1], marker='o', s=120, c=[face_colors[i]], edgecolor=[edge_colors[i]], linewidth=2, label=f'烟幕弹 {i+1} 起爆点')

    # 设置图表属性
    ax.set_xlabel('X 坐标 (m)', fontsize=14)
    ax.set_ylabel('Y 坐标 (m)', fontsize=14)
    ax.set_title(f' {solution["drone_id"]} 拦截 M1 空间策略图 ', fontsize=16)
    
    ax.set_xlim(15000, 18000)
    
    # Y轴自动适应
    path_in_view_mask = (path[:, 0] >= 15000) & (path[:, 0] <= 18000)
    if np.any(path_in_view_mask):
        path_in_view = path[path_in_view_mask]
        y_min, y_max = path_in_view[:, 1].min(), path_in_view[:, 1].max()
        y_range = max(y_max - y_min, 40) 
        y_center = (y_max + y_min) / 2
        ax.set_ylim(y_center - y_range, y_center + y_range)

    ax.legend(fontsize=12)
    ax.grid(True, linestyle=':', alpha=0.7)
    
    plt.tight_layout()


if __name__ == '__main__':
    plot_q3(solution_q3)