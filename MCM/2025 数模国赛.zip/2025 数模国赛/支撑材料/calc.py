import math
import numpy as np
import random
import copy 
import pandas as pd

eps = 1e-2
dT = 0.01
cut = 5
gravity = 9.8

M_INITIAL = [np.array([20000, 0, 2000], dtype=np.float64),
             np.array([19000, 600, 2100], dtype=np.float64),
             np.array([18000, -600, 1900], dtype=np.float64)]
FY_INITIAL = [np.array([17800, 0, 1800], dtype=np.float64),
              np.array([12000, 1400, 1400], dtype=np.float64),
              np.array([6000, -3000, 700], dtype=np.float64),
              np.array([11000, 2000, 1800], dtype=np.float64),
              np.array([13000, -2000, 1300], dtype=np.float64)]

if __name__ == "__main__":
    df = pd.read_excel('result2.xlsx')
    print(df)
    for i in range(len(df.index)):
        if not isinstance(df.iloc[i,0], str):
            continue
        FY_id = ord(df.iloc[i,0][2]) - ord('1')
        assert (0 <= FY_id <= 2)
        assert (0 - eps <= df.iloc[i,1] <= 360 + eps)
        angle = df.iloc[i,1] / 180 * math.pi
        speed = df.iloc[i,2]
        assert (70 - eps <= speed <= 140 + eps)
        put = np.array(df.iloc[i,3:6])
        bomb = np.array(df.iloc[i,6:9])

        print(f"{FY_id}, {angle}, {speed}, {put}, {bomb}")
        unit = np.array([math.cos(angle), math.sin(angle), 0]) * speed

        t1 = [0 for i in range(2)]
        for j in range(2):
            t1[j] = (put[j] - FY_INITIAL[FY_id][j]) / unit[j]
        assert (abs(t1[0] - t1[1]) < dT)
        assert (abs((put[2] - FY_INITIAL[FY_id][2])) < eps)
        T1 = sum(t1) / len(t1)
        print(f"t1 = {T1}")

        t2 = [0 for i in range(2)]
        for j in range(2):
            t2[j] = (bomb[j] - FY_INITIAL[FY_id][j]) / unit[j]
        assert (abs(t2[0] - t2[1]) < dT)
        T2 = sum(t2) / len(t2)
        assert (abs((bomb[2] - FY_INITIAL[FY_id][2] + 0.5 * gravity * ((T2 - T1) ** 2))) < eps)
        print(f"t2 = {T2}")

        print(f"verify ok!")
