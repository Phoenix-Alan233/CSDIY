
def calculate_fitness_for_drone(individual, drone_index):
    """
    为指定的无人机计算其策略的遮蔽时间。
    """
    global M, FY
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)

    flight_angle, speed, release_t, detonation_delay = individual
    dx = math.cos(flight_angle)
    dy = math.sin(flight_angle)

    # 根据 drone_index 将策略应用到正确的无人机上
    drone_dir = [np.array([0,0,0])] * 3
    drone_dir[drone_index] = np.array([dx, dy, 0])
    
    drone_spd = [0, 0, 0]
    drone_spd[drone_index] = speed
    
    release_times = [[], [], []]
    release_times[drone_index] = [release_t]
    
    detonate_times = [[], [], []]
    detonate_times[drone_index] = [release_t + detonation_delay]

    fitness, _ = processing(drone_dir, drone_spd, release_times, detonate_times)
    
    return fitness

def brute_force_solver(drone_index):
    """
    使用四重循环暴力枚举，为指定的无人机(drone_index)寻找最优策略。
    """
    drone_name = f"FY{drone_index + 1}"
    print("\n" + "="*60)
    print(f"--- 开始为无人机 {drone_name} 进行暴力求解 ---")

    # 定义搜索网格的分辨率
    # 角度切分数 (0-360度)
    angle_steps = 72 
    # 速度切分数 (70-140 m/s)
    speed_steps = 5
    # 投放时间切分数 (0-50s)
    time_steps = 5 
    # 延迟时间切分数 (0-18s)
    delay_steps = 5  
    
    angles = np.linspace(0, 2 * math.pi, angle_steps)
    speeds = np.linspace(speed_range[0], speed_range[1], speed_steps)
    times = np.linspace(time_range[0], time_range[1], time_steps)
    delays = np.linspace(delay_range[0], delay_range[1], delay_steps)

    best_fitness = -1.0
    best_params = None
    
    total_iterations = len(angles) * len(speeds) * len(times) * len(delays)
    current_iteration = 0
    
    #开始四重循环暴力枚举
    for angle in angles:
        for speed in speeds:
            for r_time in times:
                for d_delay in delays:
                    current_iteration += 1
                    # 构建当前策略
                    individual = [angle, speed, r_time, d_delay]
                    # 计算当前策略的适应度
                    fitness = calculate_fitness_for_drone(individual, drone_index)
                    
                    # 如果找到更优的解，则记录下来
                    if fitness > best_fitness:
                        best_fitness = fitness
                        best_params = individual

    print("-" * 30)
    print(f"为 {drone_name} 找到的最优单兵策略:")
    if best_params:
        angle, speed, r_time, d_delay = best_params
        d_time = r_time + d_delay
        print(f"飞行角度: {math.degrees(angle):.4f} 度")
        print(f"飞行速度: {speed:.4f} m/s")
        print(f"投放时间: {r_time:.4f} s")
        print(f"起爆时间: {d_time:.4f} s")
        print(f"产生的最大遮蔽时间: {best_fitness:.4f} s")
    print("-" * 30)
    
    return best_params


if __name__ == "__main__":
    
    # 分别为三架无人机运行暴力求解器
    best_strategy_fy1 = brute_force_solver(drone_index=0)
    best_strategy_fy2 = brute_force_solver(drone_index=1)
    best_strategy_fy3 = brute_force_solver(drone_index=2)

    # 作为第四问遗传算法的一个高质量种子。
    if best_strategy_fy1 and best_strategy_fy2 and best_strategy_fy3:
        brute_force_seed_for_q4 = best_strategy_fy1 + best_strategy_fy2 + best_strategy_fy3
        print("\n" + "="*60)
        print("已成功组合三架无人机的最优单兵策略，可作为第四问的高质量种子:")
        print(brute_force_seed_for_q4)
        print("="*60)