import math
import numpy as np
import random
import copy 
import pandas as pd

eps = 1e-9
dT = 0.01
cut = 5
gravity = 9.8

M_INITIAL = [np.array([20000, 0, 2000], dtype=np.float64),
             np.array([19000, 600, 2100], dtype=np.float64),
             np.array([18000, -600, 1900], dtype=np.float64)]
FY_INITIAL = [np.array([17800, 0, 1800], dtype=np.float64),
              np.array([12000, 1400, 1400], dtype=np.float64),
              np.array([6000, -3000, 700], dtype=np.float64),
              np.array([11000, 2000, 1800], dtype=np.float64),
              np.array([13000, -2000, 1300], dtype=np.float64)]

M = None
FY = None
missile_speed = 300
object_axis = np.array([0, 200, 0])
object_radius = 7
object_height = 10
cluster_speed = 3
cluster_radius = 10
effective_shielding = 20

# 在这里修改当前选择用 SELECTED_DRONE_INDEX 架无人机去尝试遮蔽 SELECTED_MISSILE_INDEX 的导弹。注意编号从0开始。
SELECTED_DRONE_INDEX = 0
SELECTED_MISSILE_INDEX = 1


def get_norm(delta):
    return np.linalg.norm(delta)

def line_point_distance(p1, p2, c):
    v = p2 - p1
    w = c - p1
    s = np.dot(w, v) / np.dot(v, v)
    s_clamped = np.clip(s, 0.0, 1.0)
    closest = p1 + s_clamped * v
    return np.linalg.norm(c - closest)

def check_if_cover(missile, cluster):
    candidate_points = []
    for i in range(cut):
        angle = 2 * math.pi / cut * i
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2]))
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2] + object_height))
    for c in candidate_points:
        dist = line_point_distance(missile, c, cluster)
        if dist > cluster_radius:
            return False
    return True

def processing(drone_direction, drone_speed, release_time, detonate_time):
    global M, FY, SELECTED_MISSILE_INDEX
    
    if isinstance(drone_direction, list):
        drone_direction = np.array(drone_direction)

    cluster = []
    total_cover_time = 0
    time_table = np.arange(0, 100, dT)
    
    
    individual_cover_times = []
    if release_time[SELECTED_DRONE_INDEX]:
        individual_cover_times = [0.0] * len(release_time[SELECTED_DRONE_INDEX])

    for T in time_table:
        for i in range(len(FY_INITIAL)):
            for j in range(len(release_time[i])):
                if j > 0:
                    assert release_time[i][j] - release_time[i][j - 1] >= 1 - eps
                if abs(T - detonate_time[i][j]) < dT:
                    cluster.append((FY[i][0], FY[i][1], 
                                    FY[i][2] - 0.5 * gravity * ((detonate_time[i][j] - release_time[i][j]) ** 2), 
                                    detonate_time[i][j], detonate_time[i][j] + effective_shielding, 
                                    j)) 
        
        is_covered_this_step = False
        for c in cluster:
            bomb_index = c[5] 
            if (T <= c[4]) and (check_if_cover(M[SELECTED_MISSILE_INDEX], (c[0], c[1], c[2] - cluster_speed * (T - c[3])))):
                is_covered_this_step = True
                if individual_cover_times:
                    individual_cover_times[bomb_index] += dT
                break
        
        if is_covered_this_step:
            total_cover_time += dT
        
        for i in range(len(M)):
            norm = get_norm(M[i])
            if norm > eps:
                unit = M[i] / norm * (missile_speed * dT)
                M[i] -= unit
        for i in range(len(FY)):
            norm = get_norm(drone_direction[i])
            if norm < eps: continue
            unit = drone_direction[i] / norm * (drone_speed[i] * dT)
            FY[i] += unit
        
    return total_cover_time, individual_cover_times


POPULATION_SIZE = 100
NUM_VARIABLES = 8 
VARIABLE_RANGES = [
    (0 , 2 * math.pi), (70 , 140),
    (0 , 40), (0 , 18),
    (1 , 15), (0 , 18),
    (1 , 15), (0 , 18),
]
MAX_GENERATIONS = 60 
CROSSOVER_RATE = 0.8
MUTATION_RATE = 0.05
TOURNAMENT_SIZE = 5
ELITISM_COUNT = 1

def initialize_population():
    
    population = []
    while len(population) < POPULATION_SIZE:
        individual = []
        for i in range(NUM_VARIABLES):
            min_val, max_val = VARIABLE_RANGES[i]
            individual.append(random.uniform(min_val, max_val))
        population.append(individual)
    return population

def calculate_fitness(individual):
    global M, FY, SELECTED_DRONE_INDEX
    
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)

    flight_angle, speed, \
    r_time1, d_delay1, \
    r_interval2, d_delay2, \
    r_interval3, d_delay3 = individual
    
    r_time2 = r_time1 + r_interval2
    r_time3 = r_time2 + r_interval3
    dx = math.cos(flight_angle)
    dy = math.sin(flight_angle)
    
    
    num_drones = len(FY_INITIAL)
    drone_dir = [np.array([0, 0, 0])] * num_drones
    drone_spd = [0.0] * num_drones
    release_times = [[] for _ in range(num_drones)]
    detonate_times = [[] for _ in range(num_drones)]


    drone_dir[SELECTED_DRONE_INDEX] = np.array([dx, dy, 0])
    drone_spd[SELECTED_DRONE_INDEX] = speed
    release_times[SELECTED_DRONE_INDEX] = [r_time1, r_time2, r_time3]
    detonate_times[SELECTED_DRONE_INDEX] = [r_time1 + d_delay1, r_time2 + d_delay2, r_time3 + d_delay3]

    total_fitness, _ = processing(drone_dir, drone_spd, release_times, detonate_times)
    
    return total_fitness
    
def selection(population, fitnesses):
    tournament = random.sample(list(enumerate(population)), TOURNAMENT_SIZE)
    best_individual = max(tournament, key=lambda item: fitnesses[item[0]])[1]
    return best_individual

def crossover(parent1, parent2):
    if random.random() > CROSSOVER_RATE: return parent1[:], parent2[:]  
    point = random.randint(1, NUM_VARIABLES - 1)
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    return child1, child2

def mutate(individual):
    for i in range(NUM_VARIABLES):
        if random.random() < MUTATION_RATE:
            min_val, max_val = VARIABLE_RANGES[i]
            individual[i] = random.uniform(min_val, max_val)
    return individual

def printqwq(global_best_individual, drone_idx, missile_idx):
    
    global M, FY
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)
    
    flight_angle, speed, r_t1, d_d1, r_i2, d_d2, r_i3, d_d3 = global_best_individual
    r_t2 = r_t1 + r_i2; r_t3 = r_t2 + r_i3
    dx = math.cos(flight_angle); dy = math.sin(flight_angle)
    
    num_drones = len(FY_INITIAL)
    drone_dir = [np.array([0, 0, 0])] * num_drones
    drone_spd = [0.0] * num_drones
    release_times = [[] for _ in range(num_drones)]
    detonate_times = [[] for _ in range(num_drones)]

    drone_dir[drone_idx] = np.array([dx, dy, 0])
    drone_spd[drone_idx] = speed
    release_times[drone_idx] = [r_t1, r_t2, r_t3]
    detonate_times[drone_idx] = [r_t1+d_d1, r_t2+d_d2, r_t3+d_d3]

    final_total_time, individual_times = processing(drone_dir, drone_spd, release_times, detonate_times)

    release_times_list = [r_t1, r_t2, r_t3]
    detonation_delays_list = [d_d1, d_d2, d_d3]
    
    print(f"无人机 FY{drone_idx + 1} 飞行速度: {speed:.4f} m/s")
    print(f"飞行角度: {math.degrees(flight_angle):.4f} 度")

    for i in range(3):
        print(f"烟幕弹 {i+1} 投放时间: {release_times_list[i]:.4f} s | 起爆时间: {release_times_list[i] + detonation_delays_list[i]:.4f} s" )

    if individual_times:
        for i, t in enumerate(individual_times):
            print(f"烟幕弹 {i+1} 贡献时长：{t:.4f} s")
        
    print(f"\n针对导弹 M{missile_idx + 1} 的最长有效遮蔽时间: {final_total_time:.4f} s")
    print("="*40)

def genetic_algorithm():
    population = initialize_population()
    global_best_individual = None
    global_best_fitness = -float('inf')
    
    for g in range(MAX_GENERATIONS):
        fitnesses = [calculate_fitness(ind) for ind in population]
        
        current_best_idx = np.argmax(fitnesses)
        if fitnesses[current_best_idx] > global_best_fitness:
            global_best_fitness = fitnesses[current_best_idx]
            global_best_individual = population[current_best_idx]

        print(f"第 {g+1}/{MAX_GENERATIONS} 代")
        print(f"当前最优解 (FY{SELECTED_DRONE_INDEX+1} vs M{SELECTED_MISSILE_INDEX+1}):")
        printqwq(global_best_individual, SELECTED_DRONE_INDEX, SELECTED_MISSILE_INDEX)
            
        next_generation = []
        sorted_population = sorted(zip(population, fitnesses), key=lambda x: x[1], reverse=True)
        for i in range(ELITISM_COUNT):
            next_generation.append(sorted_population[i][0])
            
        while len(next_generation) < POPULATION_SIZE:
            parent1 = selection(population, fitnesses)
            parent2 = selection(population, fitnesses)
            child1, child2 = crossover(parent1, parent2)
            mutate(child1); mutate(child2)
            next_generation.append(child1)
            if len(next_generation) < POPULATION_SIZE:
                next_generation.append(child2)
        population = next_generation

    print("\n" + "="*20 + " 最终优化结果 " + "="*20)
    printqwq(global_best_individual, SELECTED_DRONE_INDEX, SELECTED_MISSILE_INDEX)

    return global_best_individual, global_best_fitness

if __name__ == "__main__":

    print(f"将使用 [无人机 FY{SELECTED_DRONE_INDEX + 1}] 拦截 [导弹 M{SELECTED_MISSILE_INDEX + 1}]。")

    best_solution, best_value = genetic_algorithm()