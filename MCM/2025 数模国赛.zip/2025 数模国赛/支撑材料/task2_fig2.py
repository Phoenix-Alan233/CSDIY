# -*- coding: utf-8 -*-

"""
drone_direction = [6.7]
drone_speed = [140]
release_time = [[0.1]]
detonate_time = [[0.7]]
下的数据分析
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline
import matplotlib as mpl
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize, LinearSegmentedColormap

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'WenQuanYi Micro Hei']
plt.rcParams['axes.unicode_minus'] = False

x_list = np.arange(0, 15)
y_list = [2.8299999999999836, 3.429999999999971, 3.8599999999999617, 4.1699999999999555, 4.399999999999951, 4.549999999999947, 4.629999999999946, 4.629999999999946, 4.579999999999947, 4.3599999999999515, 3.979999999999959, 3.5399999999999685, 3.0599999999999787, 2.4599999999999915, 1.5300000000000011]

BOUNDS = 15
x_list = x_list[:BOUNDS]
y_list = y_list[:BOUNDS]

# 创建图形和主坐标轴
fig, ax = plt.subplots(figsize=(16, 10))

# colors = [(135/255, 206/255, 235/255), (0/255, 100/255, 0/255)]
colors = [
    (135/255, 206/255, 235/255),  # 起点：天蓝色 (SkyBlue)
    (127/255, 198/255, 226/255),
    (119/255, 190/255, 217/255),
    (111/255, 182/255, 208/255),
    (103/255, 174/255, 199/255),
    (95/255, 166/255, 190/255),
    (87/255, 158/255, 181/255),
    (79/255, 150/255, 172/255),
    (71/255, 142/255, 163/255),
    (63/255, 134/255, 154/255),
    (55/255, 126/255, 145/255),
    (47/255, 118/255, 136/255),
    (39/255, 110/255, 127/255),
    (31/255, 102/255, 118/255),
    (23/255, 94/255, 109/255),
    (15/255, 86/255, 100/255),
    (12/255, 88/255, 90/255),
    (9/255, 90/255, 80/255),
    (6/255, 92/255, 70/255),
    (4/255, 94/255, 60/255),
    (2/255, 96/255, 50/255),
    (1/255, 98/255, 40/255),
    (0/255, 100/255, 30/255),
    (0/255, 100/255, 20/255),
    (0/255, 100/255, 10/255),
    (0/255, 100/255, 0/255)   # 终点：深绿色 (DarkGreen)
]

# colors = [(135/255, 175/255, 205/255), (0/255, 100/255, 0/255)]
cmap = LinearSegmentedColormap.from_list('custom_cmap', colors, N=100)

# 归一化数据值到0-1范围
norm = Normalize(vmin=min(y_list), vmax=max(y_list))

# 为每个柱子分配颜色
bar_colors = [cmap(norm(value)) for value in y_list]

# 绘制原始数据点（使用渐变色）
bars = ax.bar(x_list, y_list, color=bar_colors, alpha=0.8)

# 设置图形标题和坐标轴标签
ax.set_title('无人机运动方向角与有效遮蔽时长关系', fontsize=16)
ax.set_xlabel('无人机运动方向角（度）', fontsize=12)
ax.set_ylabel('有效遮蔽时长（秒）', fontsize=12)
ax.set_ylim(0, max(y_list) * 1.2)  # 将y轴上限设置为数据最大值的1.2倍

# 添加网格线
ax.grid(True, alpha=0.3)

# 添加颜色条
sm = ScalarMappable(cmap=cmap, norm=norm)
sm.set_array([])
cbar = plt.colorbar(sm, ax=ax)
cbar.set_label('有效遮蔽时长值', fontsize=12)

# 调整布局
plt.tight_layout()

# 显示图形
plt.show()