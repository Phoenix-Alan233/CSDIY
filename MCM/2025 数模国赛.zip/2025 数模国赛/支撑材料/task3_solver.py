import math
import numpy as np
import random
import copy 

eps = 1e-9 # 无穷小量
dT = 0.01 # 单位时间
cut = 50  # 圆的切分数
gravity = 9.8 # 重力加速度

# 将初始坐标定义为常量，用于重置
M_INITIAL = [np.array([20000, 0, 2000], dtype=np.float64),
             np.array([19000, 600, 2100], dtype=np.float64),
             np.array([18000, -600, 1900], dtype=np.float64)]

FY_INITIAL = [np.array([17800, 0, 1800], dtype=np.float64),
              np.array([12000, 1400, 1400], dtype=np.float64),
              np.array([6000, -3000, 700], dtype=np.float64)]

# 定义将被 processing 函数修改的全局变量
M = None
FY = None

# 导弹速度 (单位 s)
missile_speed = 300

# 真目标的下底部圆的圆心坐标
object_axis = np.array([0, 200, 0])
# 真目标的圆柱半径
object_radius = 7
# 真目标的圆柱高度
object_height = 10

# 云团下降速度
cluster_speed = 3
# 云团半径
cluster_radius = 10
# 云团有效遮蔽时长 (单位: s)
effective_shielding = 20

def get_norm(delta):
    return np.linalg.norm(delta)

def line_point_distance(p1, p2, c):
    v = p2 - p1
    w = c - p1
    s = np.dot(w, v) / np.dot(v, v)
    s_clamped = np.clip(s, 0.0, 1.0)
    closest = p1 + s_clamped * v
    return np.linalg.norm(c - closest)

def check_if_cover(missile, cluster):
    candidate_points = []
    for i in range(cut):
        angle = 2 * math.pi / cut * i
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2]))
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2] + object_height))

    for c in candidate_points:
        dist = line_point_distance(missile, c, cluster)
        if dist > cluster_radius:
            return False
    return True

def processing(drone_direction, drone_speed, release_time, detonate_time):
    global M, FY 
    
    if isinstance(drone_direction, list): # 将 drone_direction 转化为 numpy
        drone_direction = np.array(drone_direction)

    cluster = []
    total_cover_time = 0
    time_table = np.arange(0, 100, dT)
    
    individual_cover_times = [0.0] * len(release_time[0]) if release_time[0] else []

    for T in time_table:
        for i in range(3):
            for j in range(len(release_time[i])):
                if j > 0:
                    assert release_time[i][j] - release_time[i][j - 1] >= 1 - eps
                if abs(T - detonate_time[i][j]) < dT:
                    cluster.append((FY[i][0], FY[i][1], 
                                    FY[i][2] - 0.5 * gravity * ((detonate_time[i][j] - release_time[i][j]) ** 2), 
                                    detonate_time[i][j], detonate_time[i][j] + effective_shielding, 
                                    j))
        
        
        is_covered_this_step = False
        for c in cluster:
            bomb_index = c[5] 
            if (T <= c[4]) and (check_if_cover(M[0], (c[0], c[1], c[2] - cluster_speed * (T - c[3])))):
                is_covered_this_step = True
                # 增加对应烟幕弹的独立遮蔽时间
                individual_cover_times[bomb_index] += dT
                break
        
        if is_covered_this_step:
            total_cover_time += dT
        
        # 更新导弹坐标: 朝着原点前进
        for i in range(len(M)):
            norm = get_norm(M[i])
            unit = M[i] / norm * (missile_speed * dT)
            M[i] -= unit
        # 更新无人机坐标: 朝着 drone_direction 前进
        for i in range(len(FY)):
            norm = get_norm(drone_direction[i])
            if norm < eps:
                continue
            unit = drone_direction[i] / norm * (drone_speed[i] * dT)
            FY[i] += unit
        
    return total_cover_time, individual_cover_times

#遗传算法参数

POPULATION_SIZE = 100
# 变量: [目标x, 目标y, 速度, 投放时间1, 延迟1, 投放间隔2, 延迟2, 投放间隔3, 延迟3]
NUM_VARIABLES = 8 
VARIABLE_RANGES = [
    (0 , 2 * math.pi),
    (70 , 140),
    (0 , 40),
    (0 , 18),
    (1 , 15),
    (0 , 18),
    (1 , 15),
    (0 , 18),
]

MAX_GENERATIONS = 60 
CROSSOVER_RATE = 0.8        
MUTATION_RATE = 0.05        
TOURNAMENT_SIZE = 5         
ELITISM_COUNT = 1          

def initialize_population():
    population = []

    while len(population) < POPULATION_SIZE:
        individual = []
        for i in range(NUM_VARIABLES):
            min_val, max_val = VARIABLE_RANGES[i]
            individual.append(random.uniform(min_val, max_val))
        population.append(individual)
    return population

def calculate_fitness(individual):
    global M, FY
    
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)

    flight_angle, speed, \
    r_time1, d_delay1, \
    r_interval2, d_delay2, \
    r_interval3, d_delay3 = individual
    
    r_time2 = r_time1 + r_interval2
    r_time3 = r_time2 + r_interval3

    dx = math.cos(flight_angle)
    dy = math.sin(flight_angle)
    
    drone_dir = [np.array([dx, dy, 0]),
                 np.array([0, 0, 0]),
                 np.array([0, 0, 0])]
    drone_spd = [speed, 0, 0]
    
    release_times = [[r_time1, r_time2, r_time3], [], []]
    detonate_times = [[r_time1 + d_delay1, r_time2 + d_delay2, r_time3 + d_delay3], [], []]

    total_fitness, _ = processing(drone_dir, drone_spd, release_times, detonate_times)
    
    return total_fitness
    
    

def selection(population, fitnesses):
    tournament = random.sample(list(enumerate(population)), TOURNAMENT_SIZE)
    best_individual = max(tournament, key=lambda item: fitnesses[item[0]])[1]
    return best_individual

def crossover(parent1, parent2):
    if random.random() > CROSSOVER_RATE:
        return parent1[:], parent2[:]  
    point = random.randint(1, NUM_VARIABLES - 1)
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    return child1, child2

def mutate(individual):
    for i in range(NUM_VARIABLES):
        if random.random() < MUTATION_RATE:
            min_val, max_val = VARIABLE_RANGES[i]
            individual[i] = random.uniform(min_val, max_val)
    return individual



def printqwq(global_best_individual):
    global M, FY
        
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)
    flight_angle, speed, r_t1, d_d1, r_i2, d_d2, r_i3, d_d3 = global_best_individual
    r_t2 = r_t1 + r_i2
    r_t3 = r_t2 + r_i3
    dx = math.cos(flight_angle)
    dy = math.sin(flight_angle)
    drone_dir = [np.array([dx, dy, 0]), np.array([0, 0, 0]), np.array([0, 0, 0])]
    drone_spd = [speed, 0, 0]
    release_times = [[r_t1, r_t2, r_t3], [], []]
    detonate_times = [[r_t1 + d_d1, r_t2 + d_d2, r_t3 + d_d3], [], []]
    
    final_total_time, individual_times = processing(drone_dir, drone_spd, release_times, detonate_times)

    release_times = [r_t1, r_t2, r_t3]
    detonation_delays = [d_d1, d_d2, d_d3]
    
    print(f"无人机飞行速度: {speed:.4f} m/s")
    print(f"飞行角度: {math.degrees(flight_angle):.4f} 度 , {flight_angle:.4f} 弧度")

    for i in range(3):
        print(f"烟幕弹 {i+1} 投放时间: {release_times[i]:.4f} s|起爆时间: {release_times[i] + detonation_delays[i]:.4f} s" )

    for i, t in enumerate(individual_times):
        print(f"烟幕弹 {i+1} 贡献时长：{t:.4f} s")
        
    print(f"\n找到的最长有效遮蔽时间: {final_total_time:.4f} s")
    
    print("="*30)



def genetic_algorithm():
    population = initialize_population()
    global_best_individual = None
    global_best_fitness = -float('inf')
    
    for g in range(MAX_GENERATIONS):
        fitnesses = [calculate_fitness(ind) for ind in population]
        
        current_best_idx = np.argmax(fitnesses)
        if fitnesses[current_best_idx] > global_best_fitness:
            global_best_fitness = fitnesses[current_best_idx]
            global_best_individual = population[current_best_idx]

        print(f"第 {g+1}/{MAX_GENERATIONS} 代: 最长遮蔽时间 = {global_best_fitness:.4f} s")

        printqwq(global_best_individual)
            
        next_generation = []
        sorted_population = sorted(zip(population, fitnesses), key=lambda x: x[1], reverse=True)
        for i in range(ELITISM_COUNT):
            next_generation.append(sorted_population[i][0])
            
        while len(next_generation) < POPULATION_SIZE:
            parent1 = selection(population, fitnesses)
            parent2 = selection(population, fitnesses)
            child1, child2 = crossover(parent1, parent2)
            mutate(child1); mutate(child2)
            next_generation.append(child1)
            if len(next_generation) < POPULATION_SIZE:
                next_generation.append(child2)
        population = next_generation

    # 解析并打印最优解
    printqwq(global_best_individual)

    return global_best_individual, global_best_fitness


if __name__ == "__main__":
    best_solution, best_value = genetic_algorithm()