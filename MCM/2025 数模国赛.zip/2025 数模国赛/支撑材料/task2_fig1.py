import math
import numpy as np
import random
import copy 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm 

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

#第二问的模拟代码(作为计算引擎)
eps = 1e-9
dT = 0.01
cut = 3
gravity = 9.8
M_INITIAL = [np.array([20000, 0, 2000], dtype=np.float64)]
FY_INITIAL = [np.array([17800, 0, 1800], dtype=np.float64)]
M = None
FY = None
missile_speed = 300
object_axis = np.array([0, 200, 0])
object_radius = 7
object_height = 10
cluster_speed = 3
cluster_radius = 10
effective_shielding = 20

def get_norm(delta):
    return np.linalg.norm(delta)

def line_point_distance(p1, p2, c):
    v = p2 - p1
    w = c - p1
    dot_v_v = np.dot(v, v)
    if dot_v_v < eps:
        return np.linalg.norm(c - p1)
    s = np.dot(w, v) / dot_v_v
    s_clamped = np.clip(s, 0.0, 1.0)
    closest = p1 + s_clamped * v
    return np.linalg.norm(c - closest)

def check_if_cover(missile, cluster):
    candidate_points = []
    for i in range(cut):
        angle = 2 * math.pi / cut * i
        candidate_points.append(np.array([object_axis[0] + object_radius * math.cos(angle), 
                                          object_axis[1] + object_radius * math.sin(angle), 
                                          object_axis[2]]))
        candidate_points.append(np.array([object_axis[0] + object_radius * math.cos(angle), 
                                          object_axis[1] + object_radius * math.sin(angle), 
                                          object_axis[2] + object_height]))
    for c_point in candidate_points:
        dist = line_point_distance(missile, c_point, cluster)
        if dist > cluster_radius:
            return False
    return True

def processing(drone_direction, drone_speed, release_time, detonate_time):
    global M, FY
    drone_direction = np.array(drone_direction)
    cluster = []
    cover_time = 0
    time_table = np.arange(0, 70, dT)
    for T in time_table:
        if len(release_time[0]) > 0 and abs(T - detonate_time[0][0]) < dT:
            cluster.append((FY[0][0], FY[0][1], 
                            FY[0][2] - 0.5 * gravity * ((detonate_time[0][0] - release_time[0][0]) ** 2), 
                            detonate_time[0][0], detonate_time[0][0] + effective_shielding))
        cover = False
        if cluster and (T <= cluster[0][4]) and (check_if_cover(M[0], (cluster[0][0], cluster[0][1], cluster[0][2] - cluster_speed * (T - cluster[0][3])))):
            cover = True
        if cover:
            cover_time += dT
        norm_m = get_norm(M[0])
        if norm_m > eps:
            unit_m = M[0] / norm_m * (missile_speed * dT)
            M[0] -= unit_m
        norm_fy = get_norm(drone_direction[0])
        if norm_fy > eps:
            unit_fy = drone_direction[0] / norm_fy * (drone_speed[0] * dT)
            FY[0] += unit_fy
    return cover_time

def calculate_fitness(individual):
    global M, FY
    M = [copy.deepcopy(M_INITIAL[0])]
    FY = [copy.deepcopy(FY_INITIAL[0])]
    flight_angle, speed, release_t, detonation_delay = individual
    dx = math.cos(flight_angle)
    dy = math.sin(flight_angle)
    drone_dir = [np.array([dx, dy, 0])]
    drone_spd = [speed]
    release_times = [[release_t]]
    detonate_times = [[release_t + detonation_delay]]
    return processing(drone_dir, drone_spd, release_times, detonate_times)

#3D可视化主函数
def plot_solution_space():
    
    angle_resolution = 40 
    speed_resolution = 30
    
    angle_degrees = np.linspace(0, 20, angle_resolution)
    speeds = np.linspace(70, 140, speed_resolution)
    
    X_angle, Y_speed = np.meshgrid(angle_degrees, speeds)
    Z_fitness = np.zeros_like(X_angle)
    
    release_t = 0.12
    detonate_t = 0.805
    detonation_delay = detonate_t - release_t
    
    #初始化变量->记录最大值
    max_fitness = -1.0
    best_angle_deg = 0
    best_speed = 0
    
    total_calculations = angle_resolution * speed_resolution
    current_calculation = 0
    for i in range(speed_resolution):
        for j in range(angle_resolution):
            current_speed = speeds[i]
            current_angle_deg = angle_degrees[j]
            current_angle_rad = np.radians(current_angle_deg)
            
            individual = [current_angle_rad, current_speed, release_t, detonation_delay]
            
            fitness = calculate_fitness(individual)
            Z_fitness[i, j] = fitness
            
            #检查并更新最大值
            if fitness > max_fitness:
                max_fitness = fitness
                best_angle_deg = current_angle_deg
                best_speed = current_speed
            
            current_calculation += 1
    
    print("\n计算完成!")

    #打印找到的最大值及其参数
    print("解空间分析结果:")
    print(f"在固定时间参数下找到的最大遮蔽时间: {max_fitness:.4f} s")
    print(f"最佳飞行角度: {best_angle_deg:.2f} 度")
    print(f"最佳飞行速度: {best_speed:.2f} m/s")

    fig = plt.figure(figsize=(14, 10))
    ax = fig.add_subplot(111, projection='3d')

    surf = ax.plot_surface(X_angle, Y_speed, Z_fitness, cmap=cm.viridis,
                           linewidth=0, antialiased=False)

    ax.set_xlabel('飞行角度 (度)', fontsize=14, labelpad=15)
    ax.set_ylabel('飞行速度 (m/s)', fontsize=14, labelpad=15)
    
    ax.set_title('解空间可视化', fontsize=18, fontweight='bold')
    
    fig.colorbar(surf, shrink=0.6, aspect=10, label='遮蔽时间 (s)')
    
    ax.view_init(elev=35, azim=-45)
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    plot_solution_space()