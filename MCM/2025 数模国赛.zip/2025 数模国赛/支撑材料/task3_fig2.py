import matplotlib.pyplot as plt

solution_q3 = {
    'drone_id': 'FY1', 'missile_id': 'M1', 'total_time': 7.36,
    'speed': 139.0863, 'angle_rad': 3.1351,
    'release_times': [0.0000, 3.6318, 5.1401],
    'detonation_times': [3.6000, 9.0207, 10.9814],
    'contributions': [3.88, 2.58, 0.90]
}

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def plot_q3_2(solution):
    plt.figure(figsize=(9, 6))
    ax = plt.gca()
    
    face_colors = [
        (250/255, 170/255, 137/255), 
        (255/255, 220/255, 126/255), 
        (173/255, 206/255, 215/255)
    ]
    darkness_factor = 0.6
    edge_colors = [tuple(c * darkness_factor for c in color) for color in face_colors]
    
    for i, d_time in enumerate(solution['detonation_times']):
        contribution_duration = solution['contributions'][i]
        
        if contribution_duration > 0:
            ax.broken_barh(
                [(d_time, contribution_duration)], 
                (i * 10, 8), 
                facecolors=face_colors[i],
                edgecolor=edge_colors[i],
                linewidth=1.5
            )
            ax.text(
                d_time + contribution_duration / 2, 
                i * 10 + 4,                        
                f'{contribution_duration:.2f}s',   
                ha='center', va='center', color='black', fontsize=12, fontweight='bold'
            )

    ax.set_yticks([4, 14, 24])
    ax.set_yticklabels(['烟幕弹 1', '烟幕弹 2', '烟幕弹 3'], fontsize=12)
    ax.set_xlabel('时间 (s)', fontsize=14)
    ax.set_title(f' {solution["drone_id"]} 各烟幕弹有效遮蔽贡献时长', fontsize=16)
    ax.grid(True, axis='x', linestyle=':', alpha=0.7)
    
    ax.invert_yaxis()
    
    plt.tight_layout()


if __name__ == '__main__':
    plot_q3_2(solution_q3)