import math
import numpy as np

eps = 1e-9 # 无穷小量

dT = 0.01 # 单位时间
cut = 50  # 圆的切分数
gravity = 9.8 # 重力加速度

# 导弹坐标
M = [np.array([20000, 0, 2000], dtype = np.float64),
     np.array([19000, 600, 2100], dtype = np.float64),
     np.array([18000, -600, 1900], dtype = np.float64)]
# 导弹速度 (单位 s)
missile_speed = 300

# 无人机坐标
FY = [np.array([17800, 0, 1800], dtype = np.float64),
      np.array([12000, 1400, 1400], dtype = np.float64),
      np.array([6000, -3000, 700], dtype = np.float64)]

# 真目标的下底部圆的圆心坐标
object_axis = np.array([0, 200, 0])
# 真目标的圆柱半径
object_radius = 7
# 真目标的圆柱高度
object_height = 10

# 云团下降速度
cluster_speed = 3
# 云团半径
cluster_radius = 10
# 云团有效遮蔽时长 (单位: s)
effective_shielding = 20

def get_norm(delta):
    """
    获取向量 (delta_x, delta_y, delta_z) 的模长
    """
    return np.linalg.norm(delta)

def line_point_distance(p1, p2, c):
    """点 c 到线段 p1-p2 的最小距离"""
    v = p2 - p1
    w = c - p1
    s = np.dot(w, v) / np.dot(v, v)
    s_clamped = np.clip(s, 0.0, 1.0)
    closest = p1 + s_clamped * v
    return np.linalg.norm(c - closest)

def check_if_cover(missile, cluster):
    """
    missile 为导弹坐标
    cluster 为云团球心坐标
    """
    candidate_points = []
    for i in range(cut):
        angle = 2 * math.pi / cut * i
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2]))
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2] + object_height))

    for c in candidate_points:
        dist = line_point_distance(missile, c, cluster)
        if dist > cluster_radius:
            return False
    return True

def processing(drone_direction, drone_speed, release_time, detonate_time):
    """
    处理问题 1.
    drone_direction: 无人机的飞行方向
    drone_speed:     飞行速度
    release_time:    炸弹投放时间
    detonate_time:   炸弹起爆时间
    """

    if isinstance(drone_direction, list): # 将 drone_direction 转化为 numpy
        drone_direction = np.array(drone_direction)

    cluster = []
    cover_time = 0
    time_table = np.arange(0, 100, dT)

    for T in time_table:
        for i in range(3): # 枚举无人机编号 i
            assert len(release_time[i]) == len(detonate_time[i])
            for j in range(len(release_time[i])): # 枚举第 j 个炸弹
                if j > 0:
                    assert release_time[i][j] - release_time[i][j - 1] >= 1 - eps
                if abs(T - detonate_time[i][j]) < dT:
                    cluster.append((FY[i][0], 
                                    FY[i][1], 
                                    FY[i][2] - 0.5 * gravity * ((detonate_time[i][j] - release_time[i][j]) ** 2), 
                                    detonate_time[i][j], detonate_time[i][j] + effective_shielding))
        
        cover = False
        for c in cluster:
            if (T <= c[4]) and (check_if_cover(M[0], (c[0], c[1], c[2] - cluster_speed * (T - c[3]))) == True):
                cover = True
        if cover == True:
            # print(f'T = {T}')
            cover_time += dT
        
        # 更新导弹坐标: 朝着原点前进
        for i in range(3):
            norm = get_norm(M[i])
            unit = M[i] / norm * (missile_speed * dT)
            M[i] -= unit
        # 更新无人机坐标: 朝着 drone_direction 前进
        for i in range(3):
            norm = get_norm(drone_direction[i])
            if norm < eps:
                continue
            unit = drone_direction[i] / norm * (drone_speed[i] * dT)
            FY[i] += unit

    print(f"cover_time = {cover_time}")
    return cover_time

if __name__ == "__main__":
    drone_direction = [[-1, 0, 0], [0, 0, 0], [0, 0, 0]]
    drone_speed = [120, 120, 120]
    release_time = [[1.5], [], []]
    detonate_time = [[5.1], [], []]
    processing(drone_direction, drone_speed, release_time, detonate_time)