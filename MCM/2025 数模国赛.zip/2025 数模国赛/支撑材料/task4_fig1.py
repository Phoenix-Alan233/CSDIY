import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D 

solutions_data_q4 = [
    {
        'drone_id': 'FY1', 'total_time': 4.64,
        'covered_interval': [1.16, 5.80],
        'release_time': 0.1, 'detonation_time': 0.7,
    },
    {
        'drone_id': 'FY2', 'total_time': 4.13,
        'covered_interval': [17.93, 22.06],
        'release_time': 9.2, 'detonation_time': 13.6,
    },
    {
        'drone_id': 'FY3', 'total_time': 2.65,
        'covered_interval': [39.10, 41.75],
        'release_time': 24.1290, 'detonation_time': 25.0796,
    }
]

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def plot_q4(solutions):
    plt.figure(figsize=(9, 2))
    ax = plt.gca()
    
    # 设定配色方案
    face_colors = [
        (250/255, 170/255, 137/255),
        (255/255, 220/255, 126/255),
        (173/255, 206/255, 215/255)
    ]
    darkness_factor = 0.6
    edge_colors = [tuple(c * darkness_factor for c in color) for color in face_colors]

    # 遍历每架无人机的策略数据
    for i, sol in enumerate(solutions):
        start_time = sol['covered_interval'][0]
        duration = sol['covered_interval'][1] - start_time
        
        if duration > 0:
            ax.broken_barh(
                [(start_time, duration)], (i * 10, 8), 
                facecolors=face_colors[i], edgecolor=edge_colors[i], linewidth=1.5
            )
            ax.text(
                start_time + duration / 2, i * 10 + 4,                        
                f'{sol["total_time"]:.2f}s',   
                ha='center', va='center', color='black', fontsize=12, fontweight='bold'
            )
        
        # 使用匹配的颜色绘制竖线
        # 投放时间线
        ax.axvline(x=sol['release_time'], color=edge_colors[i], linestyle='--', linewidth=1.5)
        
        # 起爆时间线
        ax.axvline(x=sol['detonation_time'], color=edge_colors[i], linestyle=':', linewidth=2)

    # 设置图表属性
    y_labels = [f'无人机 {s["drone_id"]}' for s in solutions]
    ax.set_yticks([4 + i*10 for i in range(len(solutions))])
    ax.set_yticklabels(y_labels, fontsize=12)
    
    ax.set_xlabel('时间 (s)', fontsize=14)
    ax.set_title('问题四: 多无人机协同遮蔽贡献时长及关键行动节点', fontsize=16)
    ax.grid(True, axis='x', linestyle=':', alpha=0.7)
    
    #创建图例
    legend_elements = [
        Line2D([0], [0], color='gray', linestyle='--', lw=1.5, label='投放时间'),
        Line2D([0], [0], color='gray', linestyle=':', lw=2, label='起爆时间')
    ]
    ax.legend(handles=legend_elements, fontsize=12)
    
    ax.invert_yaxis()
    
    plt.tight_layout()

if __name__ == '__main__':
    plot_q4(solutions_data_q4)