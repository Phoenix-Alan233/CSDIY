import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import colorsys
from matplotlib.lines import Line2D

# 所有无人机-导弹组合的最优解数据:无人机ID, 导弹ID, 总遮蔽时长, 以及详细的策略参数
all_solutions = [
    {'drone_id': 'FY1', 'missile_id': 'M1', 'total_time': 7.36, 'speed': 139.0863, 'angle_rad': 3.1351, 'release_times': [0.0, 3.6318, 5.1401], 'detonation_times': [3.6, 9.0207, 10.9814], 'contributions': [3.88, 2.58, 0.9]},
    {'drone_id': 'FY2', 'missile_id': 'M1', 'total_time': 6.73, 'speed': 128.9007, 'angle_rad': math.radians(298.2001), 'release_times': [6.9977, 7.9977, 12.5691], 'detonation_times': [11.9973, 12.2341, 16.1039], 'contributions': [3.9, 2.83, 0.0]},
    {'drone_id': 'FY2', 'missile_id': 'M2', 'total_time': 2.09, 'speed': 105.3828, 'angle_rad': math.radians(305.3116), 'release_times': [11.2414, 13.0517, 15.7915], 'detonation_times': [11.2494, 25.5799, 15.7915], 'contributions': [2.09, 0.0, 0.0]},
    {'drone_id': 'FY2', 'missile_id': 'M3', 'total_time': 2.87, 'speed': 134.6669, 'angle_rad': math.radians(210.2289), 'release_times': [14.6209, 15.6209, 16.6209], 'detonation_times': [31.8574, 24.9551, 25.0954], 'contributions': [0.0, 2.87, 0.0]},
    {'drone_id': 'FY3', 'missile_id': 'M1', 'total_time': 2.85, 'speed': 86.891, 'angle_rad': math.radians(83.6918), 'release_times': [31.9518, 32.9518, 36.574], 'detonation_times': [35.4267, 34.1039, 52.5588], 'contributions': [2.85, 0.0, 0.0]},
    {'drone_id': 'FY3', 'missile_id': 'M2', 'total_time': 2.75, 'speed': 110.4942, 'angle_rad': math.radians(116.9357), 'release_times': [15.2846, 26.3097, 31.6097], 'detonation_times': [23.2063, 32.8545, 37.987], 'contributions': [0.0, 2.75, 0.0]},
    {'drone_id': 'FY3', 'missile_id': 'M3', 'total_time': 5.83, 'speed': 136.6141, 'angle_rad': math.radians(88.6763), 'release_times': [18.0132, 19.0132, 25.9874], 'detonation_times': [21.1283, 20.7856, 33.1704], 'contributions': [3.24, 2.59, 0.0]},
    {'drone_id': 'FY4', 'missile_id': 'M1', 'total_time': 3.20, 'speed': 84.0966, 'angle_rad': math.radians(232.7399), 'release_times': [16.5168, 25.6733, 40.5499], 'detonation_times': [29.6269, 38.7834, 52.4294], 'contributions': [3.2, 0.0, 0.0]},
    {'drone_id': 'FY4', 'missile_id': 'M2', 'total_time': 3.67, 'speed': 88.033, 'angle_rad': math.radians(254.3381), 'release_times': [7.9728, 8.9728, 23.0555], 'detonation_times': [19.2884, 22.8942, 37.4687], 'contributions': [3.67, 0.0, 0.0]},
    {'drone_id': 'FY5', 'missile_id': 'M1', 'total_time': 7.88, 'speed': 139.795, 'angle_rad': math.radians(94.6146), 'release_times': [13.1986, 14.1986, 21.8122], 'detonation_times': [14.5604, 14.442, 21.8122], 'contributions': [4.05, 3.83, 0.0]},
    {'drone_id': 'FY5', 'missile_id': 'M2', 'total_time': 3.60, 'speed': 135.9522, 'angle_rad': math.radians(123.286), 'release_times': [17.559, 18.559, 19.559], 'detonation_times': [35.2421, 20.8609, 35.3786], 'contributions': [0.0, 3.6, 0.0]},
    {'drone_id': 'FY5', 'missile_id': 'M3', 'total_time': 1.99, 'speed': 101.298, 'angle_rad': math.radians(112.8724), 'release_times': [16.3256, 29.8333, 42.4709], 'detonation_times': [17.0495, 40.7531, 49.1213], 'contributions': [1.99, 0.0, 0.0]}
]

def select_best_assignments(options):
    """
    使用贪心策略，从所有可能的拦截方案中选择最优的5个任务分配。
    """
    # 按总遮蔽时间降序排列所有方案
    sorted_options = sorted(options, key=lambda x: x['total_time'], reverse=True)
    
    final_assignments = []
    drones_in_use = set()
    
    for option in sorted_options:
        if len(drones_in_use) >= 5:
            break
        if option['drone_id'] not in drones_in_use:
            final_assignments.append(option)
            drones_in_use.add(option['drone_id'])
            
    return final_assignments

def calculate_coverage_times(assignments):
    """
    根据最终的任务分配，精确计算名义总时间和有效总时间（并集）。
    """
    # 名义总时间 = 简单将各任务的总时长相加
    nominal_time = sum(task['total_time'] for task in assignments)
    
    # 构建每个导弹的遮蔽时间段列表
    intervals = {'M1': [], 'M2': [], 'M3': []}
    for task in assignments:
        missile = task['missile_id']
        for i, det_time in enumerate(task['detonation_times']):
            contribution = task['contributions'][i]
            if contribution > 0:
                intervals[missile].append([det_time, det_time + contribution])

    def merge_intervals(interval_list):
        """核心算法：合并重叠的时间区间"""
        if not interval_list:
            return 0
        
        interval_list.sort(key=lambda x: x[0])
        
        merged_list = [interval_list[0]]
        for current_start, current_end in interval_list[1:]:
            _, last_end = merged_list[-1]
            if current_start <= last_end:
                merged_list[-1][1] = max(last_end, current_end)
            else:
                merged_list.append([current_start, current_end])
                
        return sum(end - start for start, end in merged_list)

    # 分别计算每个导弹的有效遮蔽时间
    effective_m1 = merge_intervals(intervals['M1'])
    effective_m2 = merge_intervals(intervals['M2'])
    effective_m3 = merge_intervals(intervals['M3'])
    
    effective_total = effective_m1 + effective_m2 + effective_m3
    
    details = {'M1': effective_m1, 'M2': effective_m2, 'M3': effective_m3}
    
    return nominal_time, effective_total, details


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def create_heatmap(all_data, selected_tasks):
    """
    绘制任务分配效益热力图。
    """
    # 准备表格数据
    drone_ids = sorted(list(set(s['drone_id'] for s in all_data)))
    missile_ids = ['M1', 'M2', 'M3']
    heatmap_data = pd.DataFrame(0.0, index=drone_ids, columns=missile_ids)
    for item in all_data:
        heatmap_data.loc[item['drone_id'], item['missile_id']] = item['total_time']
    
    plt.figure(figsize=(9, 6))
    ax = sns.heatmap(
        heatmap_data, annot=True, fmt=".2f",
        cmap=sns.color_palette("crest", as_cmap=True), 
        linewidths=.5, cbar_kws={'label': '最大遮蔽时间 (s)'}
    )

    #高亮选中的任务
    selected_set = {(task['drone_id'], task['missile_id']) for task in selected_tasks}
    for r_idx, drone in enumerate(drone_ids):
        for c_idx, missile in enumerate(missile_ids):
            if (drone, missile) in selected_set:
                ax.add_patch(
                    plt.Rectangle(
                        (c_idx, r_idx), 1, 1, fill=False,
                        edgecolor="#FFB951", lw=3 
                    )
                )
    
    #解决边框被裁切的问题
    ax.set_xlim(-0.05, len(missile_ids) + 0.05)
    ax.set_ylim(len(drone_ids) + 0.05, -0.05)
    
    ax.set_title('问题五: 任务分配效益热力图 (黄框为最优指派)', fontsize=16)
    plt.tight_layout()


def create_gantt_chart(selected_tasks):
    """
    绘制最终协同策略图。
    """
    plt.figure(figsize=(18, 4)) 
    ax = plt.gca()
    
    def adjust_color(rgb, sat_f=1.0, val_f=1.0):
        h, s, v = colorsys.rgb_to_hsv(*rgb)
        return colorsys.hsv_to_rgb(h, min(1, s*sat_f), min(1, v*val_f))

    #手动选择合适的颜色方案
    drone_colors = {
        'FY1':(250/255,170/255,137/255), 'FY2':(255/255,220/255,126/255),
        'FY3':(173/255,206/255,215/255), 'FY4':(126/255,162/255,237/255),
        'FY5':(158/255,148/255,182/255)
    }
    drone_colors['FY2'] = adjust_color(drone_colors['FY2'], sat_f=0.85, val_f=0.85)
    drone_colors['FY3'] = adjust_color(drone_colors['FY3'], sat_f=0.85, val_f=0.85)
    drone_colors['FY5'] = adjust_color(drone_colors['FY5'], sat_f=0.8, val_f=1.1)
    
    border_colors = {d: tuple(c*0.6 for c in color) for d, color in drone_colors.items()}

    # 定义Y轴布局
    missile_lanes = {'M1': 6, 'M2': 3, 'M3': 0}
    bar_h = 0.8
    gap_h = 0.2
    
    tasks_per_missile = {'M1': [], 'M2': [], 'M3': []}
    for task in selected_tasks:
        tasks_per_missile[task['missile_id']].append(task['drone_id'])
    
    for task in selected_tasks:
        drone = task['drone_id']
        missile = task['missile_id']
        
        sub_lane_idx = tasks_per_missile[missile].index(drone)
        y_base = missile_lanes[missile]
        y_final = y_base - sub_lane_idx * (bar_h + gap_h)
        
        last_text_end = -1
        text_up = True
        
        #准备并排序贡献条带
        contributions = sorted(
            [{'start': task['detonation_times'][i], 'duration': c} for i, c in enumerate(task['contributions']) if c > 0],
            key=lambda x: x['start']
        )
        
        for item in contributions:
            start_time, duration = item['start'], item['duration']
            ax.broken_barh(
                [(start_time, duration)], (y_final, bar_h),
                facecolors=drone_colors[drone], edgecolor=border_colors[drone], linewidth=1.0
            )
            
            # 智能调整文本位置使其不重叠
            if start_time < last_text_end:
                text_up = not text_up
            
            y_text = y_final + bar_h + 0.05 if text_up else y_final - 0.05
            v_align = 'bottom' if text_up else 'top'
            
            ax.text(
                start_time + duration/2, y_text, f"[{start_time:.1f}-{start_time+duration:.1f}]",
                ha='center', va=v_align, fontsize=8, color=border_colors[drone]
            )
            last_text_end = start_time + duration

    # 设置图表格式
    ax.set_yticks([missile_lanes[m] - (len(d_list)-1)*(bar_h+gap_h)/2 for m, d_list in tasks_per_missile.items() if d_list])
    ax.set_yticklabels([m for m, d_list in tasks_per_missile.items() if d_list], fontsize=12)
    ax.set_ylim(-1.5, 9.5)
    ax.set_xlabel('时间 (s)', fontsize=14)
    ax.set_title('问题五: 最终协同策略总览甘特图', fontsize=16)
    ax.grid(True, axis='x', linestyle=':', alpha=0.7)
    
    # 创建双图例
    color_legend = [plt.Rectangle((0,0),1,1, color=drone_colors[d], label=d) for d in sorted(drone_colors.keys())]
    
    leg1 = ax.legend(handles=color_legend, title='执行无人机', fontsize=10, loc='upper right')
    ax.add_artist(leg1)
    
    plt.tight_layout()


if __name__ == '__main__':
    #确定最终策略
    final_strategy = select_best_assignments(all_solutions)
    
    #计算总时间
    nominal, effective, details = calculate_coverage_times(final_strategy)
    
    print("\n最优任务分配:")
    for task in final_strategy:
        print(f"指派 {task['drone_id']} 拦截 {task['missile_id']} (单项名义效益: {task['total_time']:.2f}s)")
        
    print("\n总体遮蔽时间分析:")
    print(f"名义总时间 (求和，有重叠): {nominal:.2f} 秒")
    print(f"有效总时间 (并集，无重叠): {effective:.2f} 秒")
    print("-M1 有效遮蔽: {:.2f} 秒".format(details['M1']))
    print("-M2 有效遮蔽: {:.2f} 秒".format(details['M2']))
    print("-M3 有效遮蔽: {:.2f} 秒".format(details['M3']))
    
    
    create_heatmap(all_solutions, final_strategy)
    
    create_gantt_chart(final_strategy)