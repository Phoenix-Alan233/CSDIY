import math
import numpy as np
import random
import copy 

eps = 1e-9 # 无穷小量
dT = 0.01 # 单位时间
cut = 50  # 圆的切分数
gravity = 9.8 # 重力加速度

# 将初始坐标定义为常量，用于重置
M_INITIAL = [np.array([20000, 0, 2000], dtype=np.float64),
             np.array([19000, 600, 2100], dtype=np.float64),
             np.array([18000, -600, 1900], dtype=np.float64)]

FY_INITIAL = [np.array([17800, 0, 1800], dtype=np.float64),
              np.array([12000, 1400, 1400], dtype=np.float64),
              np.array([6000, -3000, 700], dtype=np.float64)]

# 定义将被 processing 函数修改的全局变量
M = None
FY = None

# 导弹速度 (单位 s)
missile_speed = 300

# 真目标的下底部圆的圆心坐标
object_axis = np.array([0, 200, 0])
# 真目标的圆柱半径
object_radius = 7
# 真目标的圆柱高度
object_height = 10

# 云团下降速度
cluster_speed = 3
# 云团半径
cluster_radius = 10
# 云团有效遮蔽时长 (单位: s)
effective_shielding = 20

def get_norm(delta):
    """
    获取向量 (delta_x, delta_y, delta_z) 的模长
    """
    return np.linalg.norm(delta)

def line_point_distance(p1, p2, c):
    """点 c 到线段 p1-p2 的最小距离"""
    v = p2 - p1
    w = c - p1
    s = np.dot(w, v) / np.dot(v, v)
    s_clamped = np.clip(s, 0.0, 1.0)
    closest = p1 + s_clamped * v
    return np.linalg.norm(c - closest)

def check_if_cover(missile, cluster):
    """
    missile 为导弹坐标
    cluster 为云团球心坐标
    """
    candidate_points = []
    for i in range(cut):
        angle = 2 * math.pi / cut * i
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2]))
        candidate_points.append((object_axis[0] + object_radius * math.cos(angle), 
                                 object_axis[1] + object_radius * math.sin(angle), 
                                 object_axis[2] + object_height))

    for c in candidate_points:
        dist = line_point_distance(missile, c, cluster)
        if dist > cluster_radius:
            return False
    return True

def processing(drone_direction, drone_speed, release_time, detonate_time):
    global M, FY 
    
    if isinstance(drone_direction, list): # 将 drone_direction 转化为 numpy
        drone_direction = np.array(drone_direction)

    cluster = []
    cover_time = 0
    time_table = np.arange(0, 100, dT)

    for T in time_table:
        for i in range(3): # 枚举无人机编号 i
            assert len(release_time[i]) == len(detonate_time[i])
            for j in range(len(release_time[i])): # 枚举第 j 个炸弹
                if j > 0:
                    assert release_time[i][j] - release_time[i][j - 1] >= 1 - eps
                if abs(T - detonate_time[i][j]) < dT:
                    cluster.append((FY[i][0], 
                                    FY[i][1], 
                                    FY[i][2] - 0.5 * gravity * ((detonate_time[i][j] - release_time[i][j]) ** 2), 
                                    detonate_time[i][j], detonate_time[i][j] + effective_shielding))
                    
        cover = False
        for c in cluster:
            if (T <= c[4]) and (check_if_cover(M[0], (c[0], c[1], c[2] - cluster_speed * (T - c[3]))) == True):
                cover = True
        if cover == True:
            # print(f'T = {T}')
            cover_time += dT
        
        # 更新导弹坐标: 朝着原点前进
        for i in range(3):
            norm = get_norm(M[i])
            unit = M[i] / norm * (missile_speed * dT)
            M[i] -= unit
        # 更新无人机坐标: 朝着 drone_direction 前进
        for i in range(3):
            norm = get_norm(drone_direction[i])
            if norm < eps:
                continue
            unit = drone_direction[i] / norm * (drone_speed[i] * dT)
            FY[i] += unit
        
    return cover_time



POPULATION_SIZE = 100   #种群大小
# 第二题可变变量为: [飞行角度, 飞行速度, 投放时间, 投放后起爆延迟]
NUM_VARIABLES = 4
VARIABLE_RANGES = [
    (math.pi / 2, 3 * math.pi / 2),   # 弧度，仅考虑向前飞行
    (70, 140),   
    (0.1, 50),  
    (0.1, 15),  
]

MAX_GENERATIONS = 100  # 遗传的代数
CROSSOVER_RATE = 0.8   # 交叉遗传的概率 
MUTATION_RATE = 0.05   # 变异的概率
TOURNAMENT_SIZE = 5    # 锦标赛选择的个体数列
ELITISM_COUNT = 1      # 精英保留的数量

def initialize_population():
    population = []
    while len(population) < POPULATION_SIZE:
        individual = []
        for i in range(NUM_VARIABLES):
            min_val, max_val = VARIABLE_RANGES[i]
            individual.append(random.uniform(min_val, max_val))
        population.append(individual)
    return population

def calculate_fitness(individual):
    """适应度(本题为遮蔽时间)函数，用于接入第一题的代码"""
    global M, FY
    
    # 深拷贝
    M = copy.deepcopy(M_INITIAL)
    FY = copy.deepcopy(FY_INITIAL)

    flight_angle, speed, release_t, detonation_delay = individual
    
    # 把角度换成 processing 需要的方向向量
    dx = math.cos(flight_angle)
    dy = math.sin(flight_angle)

    drone_dir = [np.array([dx, dy, 0]),
                 np.array([0, 0, 0]),
                 np.array([0, 0, 0])]
    drone_spd = [speed, 0, 0]
    release_times = [[release_t], [], []]
    detonate_times = [[release_t + detonation_delay], [], []]

    fitness = processing(drone_dir, drone_spd, release_times, detonate_times)
    
    return fitness
    
def selection(population, fitnesses):
    """锦标赛选择操作：随机挑选TOURNAMENT_SIZE个个体来打锦标赛，比出最优秀的"""
    tournament = random.sample(list(enumerate(population)), TOURNAMENT_SIZE)
    
    best_individual = None
    best_fitness = -float('inf')
    
    for index, individual in tournament:
        if fitnesses[index] > best_fitness:
            best_fitness = fitnesses[index]
            best_individual = individual
            
    return best_individual

def crossover(parent1, parent2):
    """单点交叉：随机一个交叉点，从这个交叉点后的所有染色体进行相互交换"""
    if random.random() > CROSSOVER_RATE:
        return parent1[:], parent2[:]  
    
    point = random.randint(1, NUM_VARIABLES - 1)
    
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    
    return child1, child2

def mutate(individual):
    """变异：对每个染色体单独进行有概率的变异操作"""
    for i in range(NUM_VARIABLES):
        if random.random() < MUTATION_RATE:
            min_val, max_val = VARIABLE_RANGES[i]
            individual[i] = random.uniform(min_val, max_val)
    return individual

def genetic_algorithm():
    # 先初始化初始种群
    population = initialize_population()
    global_best_individual = None
    global_best_fitness = -float('inf')
    
    # 进行 MAX_GENERATIONS 轮的遗传进化
    for g in range(MAX_GENERATIONS):

        # 为当前子代计算适应度（遮蔽时间）
        fitnesses = [calculate_fitness(ind) for ind in population]
        
        # 找当前最优
        for i in range(POPULATION_SIZE):
            if fitnesses[i] > global_best_fitness:
                global_best_fitness = fitnesses[i]
                global_best_individual = population[i]

        print(f"第 {g+1}/{MAX_GENERATIONS} 代: 最长遮蔽时间 = {global_best_fitness:.4f} s")
        
        # 开始生成下一代子代
        next_generation = []
        
        # 保留本代精英子代
        sorted_population = sorted(zip(population, fitnesses), key=lambda x: x[1], reverse=True)
        for i in range(ELITISM_COUNT):
            next_generation.append(sorted_population[i][0])
        
        # 重复进行锦标赛选择，交叉，变异，直到达到子代数量需要
        while len(next_generation) < POPULATION_SIZE:
            parent1 = selection(population, fitnesses)
            parent2 = selection(population, fitnesses)
            
            child1, child2 = crossover(parent1, parent2)
            
            mutate(child1)
            mutate(child2)
            
            next_generation.append(child1)
            if len(next_generation) < POPULATION_SIZE:
                next_generation.append(child2)
                
        population = next_generation

    flight_angle, speed, r_time, d_delay = global_best_individual
    d_time = r_time + d_delay
    
    unit_direction = np.array([math.cos(flight_angle), math.sin(flight_angle), 0])
    
    # 投放点和起爆点计算
    detonate_time = r_time + d_delay
    drone_pos_at_detonation = FY_INITIAL[0] + unit_direction * speed * detonate_time
    release_point = drone_pos_at_detonation
    detonate_point = release_point - np.array([0, 0, 0.5 * gravity * (d_delay ** 2)])

    print(f"无人机飞行速度: {speed:.4f} m/s")
    print(f"飞行角度: {math.degrees(flight_angle):.4f} 度  {flight_angle :.4f} 弧度")
    print(f"烟幕弹投放时间: {r_time:.4f} s")
    print(f"烟幕弹起爆时间: {d_time:.4f} s")
    print(f"烟幕弹投放点坐标: ({release_point[0]:.2f}, {release_point[1]:.2f}, {release_point[2]:.2f})")
    print(f"烟幕弹起爆点坐标: ({detonate_point[0]:.2f}, {detonate_point[1]:.2f}, {detonate_point[2]:.2f})")
    print(f"\n找到的最长有效遮蔽时间: {global_best_fitness:.4f} s\n")
    
    return global_best_individual, global_best_fitness

if __name__ == "__main__":
    best_solution, best_value = genetic_algorithm()